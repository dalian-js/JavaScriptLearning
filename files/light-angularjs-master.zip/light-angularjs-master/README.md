Source code for my slides "Lightweight AngularJS". You can find simple application written with the micro-framework implemented in the tutorial [here](https://mgechev.github.io/light-angularjs/).

Blog post on this topic could be found [here](http://blog.mgechev.com/2015/03/09/build-learn-your-own-light-lightweight-angularjs/).

![Do not use in production!](http://s15.postimg.org/51kgdu6ln/bart_simpson_generator.gif)